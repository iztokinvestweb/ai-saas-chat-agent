// Entry point for frontend
export default function Home() { return (<div>Admin Dashboard (MVP Scaffold)</div>) }